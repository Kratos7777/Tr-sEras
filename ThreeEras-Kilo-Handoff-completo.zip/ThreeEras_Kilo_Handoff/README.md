﻿# Pasta de transferência ThreeEras para o Kilo Code

Esta pasta reúne a auditoria, as propostas técnicas e narrativas, o protótipo geográfico e um roteiro executável para continuar o projeto dentro do repositório Java do ThreeEras.

## Como usar

1. Abra o repositório Java verdadeiro no Kilo Code.
2. Copie o conteúdo desta pasta para uma pasta temporária no repositório ou anexe os arquivos ao contexto do Kilo.
3. Peça que primeiro faça auditoria e apresente o plano da Fase 1. Depois, implemente as fases em commits pequenos na branch de trabalho, seguindo `PROMPT_KILO_CODE.md`.
4. O Kilo deve comparar esta documentação com o repositório real e atualizar arquivos equivalentes, sem criar cópias duplicadas.

## Arquivos

- `PROMPT_KILO_CODE.md`: instrução principal para o Kilo Code.
- `docs/RELATORIO_E_ARQUITETURA.md`: estado observado, recomendações, modelo de dados e plano de implementação.
- `docs/PENDENCIAS_E_CRITERIOS.md`: tarefas, critérios de aceite e dependências externas ainda impossíveis de verificar localmente.
- `docs/CAMPANHA_PRINCIPAL.md`: trajetória narrativa de referência, mantendo conteúdo proposto separado do cânone.
- `docs/IMPLEMENTACAO_CAMPANHA.md`: etapas C0–C7 e compatibilidade com as rotas existentes.
- `docs/PROTOTIPO_GEOGRAFICO_MEDIEVAL.md`: mapa conceitual Vila–Capital, sem coordenadas finais.
- `docs/CANON_AND_PROPOSALS.md`: registro de cânone, propostas e questões abertas.
- `docs/MUNDOS_E_DEPENDENCIAS.md`: mundos, Minefort e dependências, com fontes e limites conhecidos.
- `docs/PLANO_IMPLEMENTACAO.md`: plano geral previamente registrado.

Esta pasta é um pacote de orientação. Não contém um mundo Minecraft construído nem declara que a campanha já está implementada/testada.
